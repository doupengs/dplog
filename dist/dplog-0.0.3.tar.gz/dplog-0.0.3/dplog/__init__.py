# coding: utf-8

from dplog import Logger as logger
from dptool import winAddColor
from dptool import linuxAddColor
from dptool import threadingLock

__version__ = '0.0.3'